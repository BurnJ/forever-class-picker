-- Core.lua: read the text the Forever Guide planner makes ("FKB1:" + base64 lines, modules/keybinds/ingame.js).
-- Pure Lua 5.1, no game calls, so tests/lua can run it outside the game.
local _, ns = ...

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64_VALUE = {}
for i = 1, #B64 do B64_VALUE[B64:sub(i, i)] = i - 1 end

-- Base64 to bytes; nil if a character isn't base64. Spaces and line breaks from pasting are skipped.
function ns.decodeBase64(s)
	s = s:gsub("%s", "")
	local out, bits, nbits = {}, 0, 0
	for i = 1, #s do
		local c = s:sub(i, i)
		if c == "=" then break end
		local v = B64_VALUE[c]
		if not v then return nil end
		bits = bits * 64 + v
		nbits = nbits + 6
		if nbits >= 8 then
			nbits = nbits - 8
			local byte = math.floor(bits / 2 ^ nbits)
			bits = bits - byte * 2 ^ nbits
			out[#out + 1] = string.char(byte)
		end
	end
	return table.concat(out)
end

-- The binding commands an action button can have (docs/forever-actionbar-facts.md).
local function validCommand(cmd)
	local n = cmd:match("^ACTIONBUTTON(%d+)$") or cmd:match("^MULTIACTIONBAR[1-7]BUTTON(%d+)$")
	n = tonumber(n)
	return n ~= nil and n >= 1 and n <= 12
end

local MAX_SLOT = 180

-- The planner's text -> plan, or nil and a reason the player can read.
-- plan = { name, class, bars = { 2, 3 }, slots = { [slot] = { kind = "spell", ranks = { ids }, level, name }
--   or { kind = "item", id, name } }, slotOrder = { slots in the text's order }, binds = { { key, cmd } } }
function ns.parse(str)
	if type(str) ~= "string" then return nil, "Nothing pasted." end
	str = str:gsub("^%s+", ""):gsub("%s+$", "")
	if str == "" then return nil, "Nothing pasted." end
	if str:sub(1, 5) ~= "FKB1:" then
		return nil, "That isn't a Forever Keybinds text. Copy the one under \"With the addon\" on the planner."
	end
	local text = ns.decodeBase64(str:sub(6))
	if not text or text:sub(1, 5) ~= "FKB 1" then return nil, "The text is cut short or changed. Copy it again." end
	local plan = { name = "Forever Keybinds", bars = {}, slots = {}, slotOrder = {}, binds = {} }
	for line in text:gmatch("[^\n]+") do
		local tag, rest = line:match("^(%S+)%s*(.*)$")
		if tag == "class" then
			plan.class = rest
		elseif tag == "name" then
			plan.name = rest
		elseif tag == "bars" then
			for n in rest:gmatch("%d+") do
				n = tonumber(n)
				if n >= 2 and n <= 8 then plan.bars[#plan.bars + 1] = n end
			end
		elseif tag == "s" then
			local slot, ranks, level, name = rest:match("^(%d+) ([%d,]+) (%d+) (.*)$")
			slot = tonumber(slot)
			if slot and slot >= 1 and slot <= MAX_SLOT then
				local ids = {}
				for id in ranks:gmatch("%d+") do ids[#ids + 1] = tonumber(id) end
				if not plan.slots[slot] then plan.slotOrder[#plan.slotOrder + 1] = slot end
				plan.slots[slot] = { kind = "spell", ranks = ids, level = tonumber(level), name = name }
			end
		elseif tag == "i" then
			local slot, id, name = rest:match("^(%d+) (%d+) (.*)$")
			slot = tonumber(slot)
			if slot and slot >= 1 and slot <= MAX_SLOT then
				if not plan.slots[slot] then plan.slotOrder[#plan.slotOrder + 1] = slot end
				plan.slots[slot] = { kind = "item", id = tonumber(id), name = name }
			end
		elseif tag == "k" then
			local key, cmd = rest:match("^(%S+) (%S+)$")
			if key and validCommand(cmd) then plan.binds[#plan.binds + 1] = { key = key, cmd = cmd } end
		end
	end
	if not plan.class then return nil, "The text has no class in it. Copy it again." end
	return plan
end

-- The highest rank the player knows, from a list in rank order; isKnown(id) -> bool.
function ns.highestKnown(ranks, isKnown)
	for i = #ranks, 1, -1 do
		if isKnown(ranks[i]) then return ranks[i] end
	end
	return nil
end

-- Is id one of these ranks?
function ns.hasRank(ranks, id)
	for _, r in ipairs(ranks) do
		if r == id then return true end
	end
	return false
end
