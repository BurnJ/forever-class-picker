-- Apply.lua: put a plan on the bars, set its keys, and undo it. Spells the player hasn't learned wait in
-- ForeverKeybindsCharDB.pending and go in their slot when learned (after combat). Facts behind the calls:
-- docs/forever-actionbar-facts.md (C_Spell.PickupSpell puts nothing on the cursor for an unlearned spell;
-- items the player doesn't have still go on a bar).
local _, ns = ...

local MAX_SLOT = 180

local function db()
	ForeverKeybindsCharDB = ForeverKeybindsCharDB or {}
	return ForeverKeybindsCharDB
end

function ns.log(msg)
	ForeverKeybindsDB = ForeverKeybindsDB or {}
	local log = ForeverKeybindsDB.log or {}
	ForeverKeybindsDB.log = log
	log[#log + 1] = date("%Y-%m-%d %H:%M:%S") .. " " .. msg
	while #log > 200 do table.remove(log, 1) end
end

local function isKnown(id)
	if IsPlayerSpell and IsPlayerSpell(id) then return true end
	return IsSpellKnown and IsSpellKnown(id) or false
end
ns.isKnown = isKnown

-- what an action slot holds, as a small table (false when empty)
local function actionAt(slot)
	if not HasAction(slot) then return false end
	local kind, id = GetActionInfo(slot)
	return { type = kind, id = id }
end
ns.actionAt = actionAt

local function clearSlot(slot)
	if HasAction(slot) then
		PickupAction(slot)
		ClearCursor()
	end
end

-- Put a spell or item from the cursor into a slot. False if nothing got onto the cursor.
local function placeFromCursor(slot)
	if not GetCursorInfo() then return false end
	PlaceAction(slot)
	ClearCursor()
	return true
end
local function placeSpell(slot, id)
	ClearCursor()
	C_Spell.PickupSpell(id)
	return placeFromCursor(slot)
end
local function placeItem(slot, id)
	ClearCursor()
	C_Item.PickupItem(id)
	return placeFromCursor(slot)
end

local function playerClass()
	local _, token = UnitClass("player")
	return token and token:lower() or ""
end

-- every slot's contents, so learning a spell can tell which slot the game just put it in
local function snapshot()
	local snap = {}
	for slot = 1, MAX_SLOT do
		local a = actionAt(slot)
		if a then snap[slot] = a.type .. ":" .. tostring(a.id) end
	end
	return snap
end

-- What applying would do, for the window: counts and the reasons it can't.
function ns.preview(plan)
	local out = { spells = 0, later = 0, items = 0, keys = #plan.binds, bars = #plan.bars, wrongClass = false }
	if plan.class ~= playerClass() then out.wrongClass = true end
	for _, slot in ipairs(plan.slotOrder) do
		local s = plan.slots[slot]
		if s.kind == "item" then out.items = out.items + 1
		elseif ns.highestKnown(s.ranks, isKnown) then out.spells = out.spells + 1
		else out.later = out.later + 1 end
	end
	return out
end

local function getCVar(name)
	if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(name) end
	return GetCVar and GetCVar(name)
end
local function setCVar(name, value)
	if C_CVar and C_CVar.SetCVar then return pcall(C_CVar.SetCVar, name, value) end
	if SetCVar then return pcall(SetCVar, name, value) end
end

local function setBar(n, on)
	if not (Settings and Settings.GetValue and Settings.SetValue) then return nil end
	local name = "PROXY_SHOW_ACTIONBAR_" .. n
	local ok, was = pcall(Settings.GetValue, name)
	if not ok then return nil end
	pcall(Settings.SetValue, name, on)
	return was
end

-- Apply a parsed plan. Returns true and a summary, or false and why not.
function ns.apply(plan)
	if InCombatLockdown() then return false, "You're in combat. Try again after the fight." end
	if plan.class ~= playerClass() then return false, "This plan is for a " .. plan.class .. ". Log in on one to apply it." end
	local d = db()
	-- the backup covers everything this changes, so Undo can put it back
	local backup = { name = plan.name, slots = {}, binds = {}, cmdKeys = {}, bars = {}, cvars = {} }
	for _, slot in ipairs(plan.slotOrder) do backup.slots[slot] = actionAt(slot) end
	for _, b in ipairs(plan.binds) do
		if not backup.cmdKeys[b.cmd] then backup.cmdKeys[b.cmd] = { GetBindingKey(b.cmd) } end
		if backup.binds[b.key] == nil then backup.binds[b.key] = GetBindingAction(b.key) or "" end
	end
	for _, n in ipairs(plan.bars) do
		local was = setBar(n, true)
		if was ~= nil then backup.bars[n] = was end
	end
	local switched = {}
	for _, k in ipairs(plan.show or {}) do
		local sw = ns.SWITCHES[k]
		local was = getCVar(sw.cvar)
		if was ~= nil then
			backup.cvars[sw.cvar] = was
			setCVar(sw.cvar, "1")
			switched[#switched + 1] = sw.name
		end
	end

	-- keys: the buttons lose their old keys, then get the plan's
	for cmd, keys in pairs(backup.cmdKeys) do
		for _, k in ipairs(keys) do
			if backup.binds[k] == nil then backup.binds[k] = cmd end
			SetBinding(k)
		end
	end
	for _, b in ipairs(plan.binds) do SetBinding(b.key, b.cmd) end
	SaveBindings(GetCurrentBindingsSet())

	-- abilities and items
	local placed, later, items = 0, 0, 0
	d.pending, d.placed, d.planSlots = {}, {}, {}
	for _, slot in ipairs(plan.slotOrder) do
		local s = plan.slots[slot]
		d.planSlots[slot] = true
		if s.kind == "item" then
			if placeItem(slot, s.id) then items = items + 1 end
		else
			local id = ns.highestKnown(s.ranks, isKnown)
			if id and placeSpell(slot, id) then
				placed = placed + 1
				d.placed[slot] = s.ranks
			else
				clearSlot(slot)
				d.pending[slot] = { ranks = s.ranks, level = s.level, name = s.name }
				later = later + 1
			end
		end
	end
	d.backup = backup
	d.snapshot = snapshot()
	d.planName = plan.name
	ClearCursor()
	ns.log(string.format("applied %s: %d spells, %d later, %d items, %d keys", plan.name, placed, later, items, #plan.binds))
	if ns.refreshOverlays then ns.refreshOverlays() end
	local function n(count, word) return count .. " " .. word .. (count == 1 and "" or "s") end
	local msg = string.format("Done: %s and %s placed, %s set.", n(placed, "ability"):gsub("ys$", "ies"), n(items, "item"), n(#plan.binds, "key"))
	if later > 0 then msg = msg .. " " .. n(later, "button") .. " show a greyed spell you haven't learned yet; it goes on when you learn it." end
	if #switched > 0 then msg = msg .. " Turned on: " .. table.concat(switched, ", ") .. "." end
	return true, msg
end

-- Put back what the last Apply changed.
function ns.undo()
	if InCombatLockdown() then return false, "You're in combat. Try again after the fight." end
	local d = db()
	local b = d.backup
	if not b then return false, "There's nothing to undo." end
	local missed = 0
	for slot, a in pairs(b.slots) do
		if not a then clearSlot(slot)
		elseif a.type == "spell" then if not placeSpell(slot, a.id) then missed = missed + 1 end
		elseif a.type == "item" then if not placeItem(slot, a.id) then missed = missed + 1 end
		elseif a.type == "macro" and PickupMacro then ClearCursor(); PickupMacro(a.id); if not placeFromCursor(slot) then missed = missed + 1 end
		else missed = missed + 1 end
	end
	for key, cmd in pairs(b.binds) do
		if cmd == "" then SetBinding(key) else SetBinding(key, cmd) end
	end
	SaveBindings(GetCurrentBindingsSet())
	for n, was in pairs(b.bars) do setBar(n, was) end
	for name, was in pairs(b.cvars or {}) do setCVar(name, was) end
	d.backup, d.pending, d.placed, d.planSlots, d.snapshot = nil, {}, {}, {}, nil
	ClearCursor()
	ns.log("undo " .. tostring(b.name) .. (missed > 0 and (", " .. missed .. " buttons not restored") or ""))
	if ns.refreshOverlays then ns.refreshOverlays() end
	if missed > 0 then return true, "Put back, except " .. missed .. " buttons that held something the game can't place again (like a mount or a pet). Drag those back yourself." end
	return true, "Put back the way it was."
end

-- After learning spells: put newly learned planned spells in their slots, take out copies the game
-- auto-placed elsewhere, and swap placed spells up to a new rank. Waits for the end of combat.
function ns.update()
	local d = db()
	if not d.pending and not d.placed then return end
	if InCombatLockdown() then ns.waiting = true return end
	ns.waiting = false
	local learned = {}
	for slot, p in pairs(d.pending or {}) do
		local id = ns.highestKnown(p.ranks, isKnown)
		if id then
			if not HasAction(slot) and placeSpell(slot, id) then
				d.placed[slot] = p.ranks
				learned[#learned + 1] = p
				ns.log("learned " .. p.name .. ", placed in slot " .. slot)
			elseif HasAction(slot) then
				ns.log("learned " .. p.name .. ", slot " .. slot .. " was taken, left it")
			end
			d.pending[slot] = nil
		end
	end
	-- the game may have put a newly learned spell on an empty button: take it off unless it's planned there
	if #learned > 0 and d.snapshot then
		for slot = 1, MAX_SLOT do
			if not d.planSlots[slot] then
				local a = actionAt(slot)
				if a and a.type == "spell" then
					for _, p in ipairs(learned) do
						if ns.hasRank(p.ranks, a.id) and d.snapshot[slot] ~= "spell:" .. tostring(a.id) then
							clearSlot(slot)
							ns.log("took " .. p.name .. " out of slot " .. slot .. " (the game put it there)")
							break
						end
					end
				end
			end
		end
	end
	-- new ranks of placed spells
	for slot, ranks in pairs(d.placed or {}) do
		local a = actionAt(slot)
		local best = ns.highestKnown(ranks, isKnown)
		if a and a.type == "spell" and best and a.id ~= best and ns.hasRank(ranks, a.id) then
			placeSpell(slot, best)
		end
	end
	d.snapshot = snapshot()
	if ns.refreshOverlays then ns.refreshOverlays() end
end
