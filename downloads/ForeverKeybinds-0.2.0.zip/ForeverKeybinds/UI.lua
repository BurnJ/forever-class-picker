-- UI.lua: the /fkb window (paste, Apply, Undo), the greyed icons on planned buttons, and the events that
-- place spells as they're learned.
local _, ns = ...

-- Action button frames the game has (probe: docs/forever-actionbar-facts.md). Each knows its slot as .action.
local BUTTON_FAMILIES = { "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton", "MultiBarRightButton",
	"MultiBarLeftButton", "MultiBar5Button", "MultiBar6Button", "MultiBar7Button" }

local function slotOf(btn)
	local slot = btn.action
	if slot == nil and btn.GetAttribute then slot = btn:GetAttribute("action") end
	return tonumber(slot)
end

local function spellIcon(id)
	if C_Spell and C_Spell.GetSpellTexture then
		local ok, tex = pcall(C_Spell.GetSpellTexture, id)
		if ok and tex then return tex end
	end
	return GetSpellTexture and GetSpellTexture(id) or 134400  -- the question mark icon
end

local function showPlanned(btn)
	local slot = slotOf(btn)
	local p = slot and ForeverKeybindsCharDB and ForeverKeybindsCharDB.pending and ForeverKeybindsCharDB.pending[slot]
	if not p or HasAction(slot) then return end
	GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
	GameTooltip:SetSpellByID(p.ranks[1])
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine("Planned here by Forever Keybinds. It goes on this button when you learn it"
		.. (p.level and p.level > 1 and (" (level " .. p.level .. ")") or "") .. ".", 0.4, 0.8, 1, true)
	GameTooltip:Show()
end

-- Greyed icons on empty buttons whose planned spell isn't learned yet.
function ns.refreshOverlays()
	local pending = ForeverKeybindsCharDB and ForeverKeybindsCharDB.pending or {}
	for _, fam in ipairs(BUTTON_FAMILIES) do
		for i = 1, 12 do
			local btn = _G[fam .. i]
			if btn then
				local slot = slotOf(btn)
				local p = slot and pending[slot]
				if p and not HasAction(slot) then
					if not btn.fkbPlanned then
						local tex = btn:CreateTexture(nil, "OVERLAY")
						tex:SetAllPoints(btn.icon or btn)
						tex:SetDesaturated(true)
						tex:SetAlpha(0.55)
						btn.fkbPlanned = tex
						btn:HookScript("OnEnter", showPlanned)
					end
					btn.fkbPlanned:SetTexture(spellIcon(p.ranks[1]))
					btn.fkbPlanned:Show()
				elseif btn.fkbPlanned then
					btn.fkbPlanned:Hide()
				end
			end
		end
	end
end

-- The window: paste the planner's text, see what it will do, Apply or Undo.
local frame, box, summary, applyBtn, undoBtn
local current  -- the plan in the box, when it reads

local function describe(plan)
	local p = ns.preview(plan)
	if p.wrongClass then
		return "|cffff6060This plan is for a " .. plan.class .. ". Log in on one to apply it.|r", false
	end
	local text = string.format("|cffffd100%s|r\n%d abilities to place now, %d when you learn them, %d items, %d keys.",
		plan.name, p.spells, p.later, p.items, p.keys)
	if p.bars > 0 then text = text .. "\nIt switches on the action bars it uses." end
	return text .. "\nYour current buttons and keys are saved first, so Undo puts them back.", true
end

local function onText()
	local plan, err = ns.parse(box:GetText())
	current = plan
	if not plan then
		summary:SetText(box:GetText() == "" and "Paste the text from \"With the addon\" on the planner's \"Put it in the game\"." or ("|cffff6060" .. err .. "|r"))
		applyBtn:Disable()
		return
	end
	local text, ok = describe(plan)
	summary:SetText(text)
	if ok then applyBtn:Enable() else applyBtn:Disable() end
end

local function button(parent, label, x, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(110, 24)
	b:SetPoint("BOTTOMLEFT", x, 14)
	b:SetText(label)
	b:SetScript("OnClick", onClick)
	return b
end

local function buildWindow()
	frame = CreateFrame("Frame", "ForeverKeybindsFrame", UIParent, "BasicFrameTemplateWithInset")
	frame:SetSize(480, 250)
	frame:SetPoint("CENTER")
	frame:SetFrameStrata("DIALOG")
	frame:SetMovable(true)
	frame:EnableMouse(true)
	frame:RegisterForDrag("LeftButton")
	frame:SetScript("OnDragStart", frame.StartMoving)
	frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
	tinsert(UISpecialFrames, "ForeverKeybindsFrame")  -- Esc closes it
	local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	title:SetPoint("TOP", 0, -5)
	title:SetText("Forever Keybinds")

	box = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
	box:SetSize(430, 24)
	box:SetPoint("TOPLEFT", 26, -40)
	box:SetAutoFocus(false)
	box:SetMaxLetters(0)
	box:SetScript("OnTextChanged", onText)
	box:SetScript("OnEscapePressed", function() frame:Hide() end)

	summary = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	summary:SetPoint("TOPLEFT", 22, -76)
	summary:SetWidth(436)
	summary:SetJustifyH("LEFT")
	summary:SetSpacing(3)

	applyBtn = button(frame, "Apply", 20, function()
		if not current then return end
		local ok, msg = ns.apply(current)
		if ok then box:SetText("") end  -- before the message: clearing the box resets the summary
		summary:SetText(ok and ("|cff60ff60" .. msg .. "|r") or ("|cffff6060" .. msg .. "|r"))
		undoBtn:SetEnabled(ForeverKeybindsCharDB.backup ~= nil)
	end)
	undoBtn = button(frame, "Undo", 136, function()
		local ok, msg = ns.undo()
		summary:SetText(ok and ("|cff60ff60" .. msg .. "|r") or ("|cffff6060" .. msg .. "|r"))
		undoBtn:SetEnabled(ForeverKeybindsCharDB and ForeverKeybindsCharDB.backup ~= nil)
	end)
	local note = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	note:SetPoint("BOTTOMRIGHT", -20, 20)
	note:SetText("Bar positions: Edit Mode > Import")
	frame:SetScript("OnShow", function()
		onText()
		undoBtn:SetEnabled(ForeverKeybindsCharDB and ForeverKeybindsCharDB.backup ~= nil)
	end)
	frame:Hide()
end

function ns.toggle()
	if not frame then buildWindow() end
	frame:SetShown(not frame:IsShown())
	if frame:IsShown() then box:SetFocus() end
end

SLASH_FOREVERKEYBINDS1 = "/fkb"
SlashCmdList.FOREVERKEYBINDS = function(msg)
	if msg and msg:lower():match("^%s*undo") then
		local _, text = ns.undo()
		print("|cffffd100Forever Keybinds:|r " .. text)
	else
		ns.toggle()
	end
end

-- events: learning spells, leaving combat, bar pages changing
local events = CreateFrame("Frame")
local function listen(ev) pcall(events.RegisterEvent, events, ev) end  -- some events don't exist in every client
for _, ev in ipairs({ "PLAYER_LOGIN", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "PLAYER_REGEN_ENABLED",
	"ACTIONBAR_SLOT_CHANGED", "ACTIONBAR_PAGE_CHANGED", "UPDATE_BONUS_ACTIONBAR", "PLAYER_ENTERING_WORLD" }) do
	listen(ev)
end
events:SetScript("OnEvent", function(_, ev)
	if ev == "SPELLS_CHANGED" or ev == "LEARNED_SPELL_IN_TAB" or ev == "PLAYER_LOGIN"
		or (ev == "PLAYER_REGEN_ENABLED" and ns.waiting) then
		ns.update()
	end
	ns.refreshOverlays()
end)
